package com.bookmanage.bookcrud.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.bookmanage.bookcrud.model.Book;
import com.bookmanage.bookcrud.repository.BookRepository;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/books")
public class BookController {

    private final BookRepository repo;

    public BookController(BookRepository repo) {
        this.repo = repo;
    }

    // CREATE
    @PostMapping
    public Book createBook(@RequestBody Book book) {
        return repo.save(book);
    }

    // READ ALL
    @GetMapping
    public List<Book> getAllBooks() {
        return repo.findAll();
    }

    // READ BY ID
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        return repo.findById(id)
                .map(ResponseEntity::ok)                // 200 OK
                .orElse(ResponseEntity.notFound().build()); // 404 if not found
    }

    // UPDATE
    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book bookDetails) {
        return repo.findById(id)
                .map(book -> {
                    book.setTitle(bookDetails.getTitle());
                    book.setAuthor(bookDetails.getAuthor());
                    Book updatedBook = repo.save(book);
                    return ResponseEntity.ok(updatedBook);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // DELETE
    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteBook(@PathVariable Long id) {
        return repo.findById(id)
                .map(book -> {
                    repo.delete(book);
                    return ResponseEntity.noContent().build(); // 204 No Content
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
